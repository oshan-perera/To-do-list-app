import React from 'react';
import TodoApp from './components/TodoApp';
import { Toaster } from './components/ui/sonner';
import './App.css';

function App() {
  return (
    <div className="App min-h-screen gradient-subtle">
      <TodoApp />
      <Toaster position="top-center" />
    </div>
  );
}

export default App;
