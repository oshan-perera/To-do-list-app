import React, { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { toast } from 'sonner';
import { CheckCircle2, Circle, Trash2, Plus, ListTodo } from 'lucide-react';

const TodoApp = () => {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');
  const [filter, setFilter] = useState('all'); // all, active, completed

  // Load tasks from localStorage on mount
  useEffect(() => {
    const savedTasks = localStorage.getItem('todoTasks');
    if (savedTasks) {
      setTasks(JSON.parse(savedTasks));
    }
  }, []);

  // Save tasks to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('todoTasks', JSON.stringify(tasks));
  }, [tasks]);

  const addTask = () => {
    if (newTask.trim() === '') {
      toast.error('Please enter a task!');
      return;
    }

    const task = {
      id: Date.now(),
      text: newTask.trim(),
      completed: false,
      createdAt: new Date().toISOString(),
    };

    setTasks([task, ...tasks]);
    setNewTask('');
    toast.success('Task added successfully!');
  };

  const toggleTask = (taskId) => {
    setTasks(
      tasks.map((task) =>
        task.id === taskId ? { ...task, completed: !task.completed } : task
      )
    );

    const task = tasks.find((t) => t.id === taskId);
    if (!task.completed) {
      toast.success('Task completed! 🎉');
    } else {
      toast.info('Task marked as incomplete');
    }
  };

  const deleteTask = (taskId) => {
    setTasks(tasks.filter((task) => task.id !== taskId));
    toast.success('Task deleted');
  };

  const clearCompleted = () => {
    const completedCount = tasks.filter((task) => task.completed).length;
    if (completedCount === 0) {
      toast.info('No completed tasks to clear');
      return;
    }
    setTasks(tasks.filter((task) => !task.completed));
    toast.success(`Cleared ${completedCount} completed task${completedCount > 1 ? 's' : ''}`);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      addTask();
    }
  };

  const filteredTasks = tasks.filter((task) => {
    if (filter === 'active') return !task.completed;
    if (filter === 'completed') return task.completed;
    return true;
  });

  const stats = {
    total: tasks.length,
    active: tasks.filter((t) => !t.completed).length,
    completed: tasks.filter((t) => t.completed).length,
  };

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 mb-4">
            <ListTodo className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-2" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
            My Tasks
          </h1>
          <p className="text-muted-foreground text-base sm:text-lg">
            Stay organized and productive
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-3 sm:gap-4 mb-6">
          <Card className="p-4 text-center border-border/50 shadow-elegant transition-smooth hover:shadow-lg">
            <div className="text-2xl sm:text-3xl font-bold text-primary mb-1">{stats.total}</div>
            <div className="text-xs sm:text-sm text-muted-foreground">Total</div>
          </Card>
          <Card className="p-4 text-center border-border/50 shadow-elegant transition-smooth hover:shadow-lg">
            <div className="text-2xl sm:text-3xl font-bold text-accent-foreground mb-1">{stats.active}</div>
            <div className="text-xs sm:text-sm text-muted-foreground">Active</div>
          </Card>
          <Card className="p-4 text-center border-border/50 shadow-elegant transition-smooth hover:shadow-lg">
            <div className="text-2xl sm:text-3xl font-bold text-primary/70 mb-1">{stats.completed}</div>
            <div className="text-xs sm:text-sm text-muted-foreground">Done</div>
          </Card>
        </div>

        {/* Add Task Input */}
        <Card className="p-4 sm:p-6 mb-6 shadow-elegant border-border/50">
          <div className="flex gap-3">
            <Input
              type="text"
              placeholder="Add a new task..."
              value={newTask}
              onChange={(e) => setNewTask(e.target.value)}
              onKeyPress={handleKeyPress}
              className="flex-1 h-12 text-base border-input focus-visible:ring-primary"
            />
            <Button
              onClick={addTask}
              className="h-12 px-6 gradient-primary hover:opacity-90 transition-smooth shadow-md hover:shadow-lg"
            >
              <Plus className="w-5 h-5 mr-2" />
              <span className="hidden sm:inline">Add</span>
            </Button>
          </div>
        </Card>

        {/* Filter Tabs */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex gap-2">
            <Button
              variant={filter === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('all')}
              className={filter === 'all' ? 'gradient-primary' : 'hover:bg-secondary'}
            >
              All
            </Button>
            <Button
              variant={filter === 'active' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('active')}
              className={filter === 'active' ? 'gradient-primary' : 'hover:bg-secondary'}
            >
              Active
            </Button>
            <Button
              variant={filter === 'completed' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('completed')}
              className={filter === 'completed' ? 'gradient-primary' : 'hover:bg-secondary'}
            >
              Completed
            </Button>
          </div>
          {stats.completed > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearCompleted}
              className="text-destructive hover:text-destructive hover:bg-destructive/10"
            >
              Clear Completed
            </Button>
          )}
        </div>

        {/* Tasks List */}
        <div className="space-y-3">
          {filteredTasks.length === 0 ? (
            <Card className="p-12 text-center border-dashed border-2 border-border/50">
              <Circle className="w-16 h-16 mx-auto mb-4 text-muted-foreground/30" />
              <p className="text-muted-foreground text-lg mb-2">No tasks yet</p>
              <p className="text-muted-foreground/70 text-sm">
                {filter === 'all'
                  ? 'Add your first task to get started'
                  : filter === 'active'
                  ? 'No active tasks'
                  : 'No completed tasks'}
              </p>
            </Card>
          ) : (
            filteredTasks.map((task) => (
              <Card
                key={task.id}
                className={`p-4 sm:p-5 shadow-md hover:shadow-lg transition-smooth border-border/50 task-slide-in ${
                  task.completed ? 'bg-muted/30' : 'bg-card'
                }`}
              >
                <div className="flex items-center gap-4">
                  <div
                    className="flex-shrink-0 cursor-pointer"
                    onClick={() => toggleTask(task.id)}
                  >
                    {task.completed ? (
                      <CheckCircle2 className="w-6 h-6 text-primary transition-smooth" />
                    ) : (
                      <Circle className="w-6 h-6 text-muted-foreground hover:text-primary transition-smooth" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p
                      className={`text-base sm:text-lg transition-smooth ${
                        task.completed
                          ? 'line-through text-muted-foreground'
                          : 'text-foreground'
                      }`}
                    >
                      {task.text}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteTask(task.id)}
                    className="flex-shrink-0 hover:bg-destructive/10 hover:text-destructive transition-smooth"
                  >
                    <Trash2 className="w-5 h-5" />
                  </Button>
                </div>
              </Card>
            ))
          )}
        </div>

        {/* Footer Info */}
        {tasks.length > 0 && (
          <div className="mt-8 text-center">
            <p className="text-sm text-muted-foreground">
              {stats.completed > 0 && stats.active > 0
                ? `${stats.completed} task${stats.completed > 1 ? 's' : ''} completed, ${stats.active} remaining`
                : stats.completed === tasks.length
                ? '🎉 All tasks completed! Great job!'
                : `${stats.active} task${stats.active > 1 ? 's' : ''} to complete`}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TodoApp;
